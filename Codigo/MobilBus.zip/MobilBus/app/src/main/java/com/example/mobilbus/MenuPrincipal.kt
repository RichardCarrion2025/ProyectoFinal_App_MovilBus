package com.example.mobilbus

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.mobilbus.databinding.ActivityMenuPrincipalBinding

class MenuPrincipal : AppCompatActivity() {

    private lateinit var binding: ActivityMenuPrincipalBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMenuPrincipalBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Ejemplo: actualizar nombre del usuario
        val userName = "usernnn"
        binding.welcomeText.text = "Bienvenido $userName"

        // Acción para cerrar sesión
        binding.logoutText.setOnClickListener {
            // TODO: manejar cierre de sesión
            finish()
        }
    }
}
