package com.example.mobilbus

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.mobilbus.R

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val usernameInput = findViewById<EditText>(R.id.usernameInput)
        val passwordInput = findViewById<EditText>(R.id.passwordInput)
        val loginButton = findViewById<Button>(R.id.loginButton)
        val contactLink = findViewById<TextView>(R.id.contactLink)

        loginButton.setOnClickListener {
            val user = usernameInput.text.toString()
            val pass = passwordInput.text.toString()

            // Validar user
            Toast.makeText(this, "Usuario: $user", Toast.LENGTH_SHORT).show()

            //Mostrar menu principal
            val intent = Intent(this, MenuPrincipal::class.java)
            startActivity(intent)
        }

        contactLink.setOnClickListener {
            Toast.makeText(this, "Contactando al administrador...", Toast.LENGTH_SHORT).show()
        }


    }
}
